import React from 'react'

export default () => {
  return (
    <div>
      <p>page 2</p>
    </div>
  )
}
