import React, { Component } from 'react';
import Cookies from 'js-cookie';

export default class componentName extends Component {
  componentDidMount() {
    if(Cookies.get('token')) {
      console.log('token found, clearing now...')
      Cookies.remove('token')
    }else {
      console.log('token not found, thats okay, redirect to login page')
    }

    window.location = '/PanelistManager'
  }

  render() {
    return (
      <div>
        
      </div>
    )
  }
}
