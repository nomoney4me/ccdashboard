import React, {Component} from 'react';
// import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';

import PivotTableUI from 'react-pivottable/PivotTableUI';
import TableRenderers from 'react-pivottable/TableRenderers';
import Plot from 'react-plotly.js';
import createPlotlyRenderers from 'react-pivottable/PlotlyRenderers';


import 'react-pivottable/pivottable.css';
import loading from './assets/spinner.gif';

const PlotlyRenderers = createPlotlyRenderers(Plot);

class RawData extends Component {
  constructor (props) {
    super(props)
    this.state = {
      data: null,
      rawdata: null,
      rows:["market"],
      cols:[],
      isHidden:true,
    }
  }

  handleChange = (e) => {
    const {name, value} = e.target;
    this.setState(prevState => ({ [name]: [value]}))
  }

  toggleDatamap = () => {
    this.setState({
      toggleDatamap: !this.state.isHidden
    })
  }

  GetRawData = (props) => {
    let url = `https://sync.gui.cc/studiesreport/rawdata?ssid=${props.state.ssid}&batchnum=${props.state.batchnum}`
    fetch(url).then(result => {return result.json()})
      .then(result => {
        // var TextBlob = striptags(decodeURIComponent(result).replace(/\+/g, " "))
        this.setState({data:result})
        // this.setState({data:JSON.parse(TextBlob)})
      })
  }

  componentDidMount() {
    this.GetRawData(this.props)
  }

  componentDidUpdate(prevProp, prevState) {
    if( (prevProp.state.ssid !== this.props.state.ssid) || (prevProp.state.batchnum !== this.props.state.batchnum) ) {
      console.log('updating data')
      this.setState({data: null}, () => {
        this.GetRawData(this.props)
      })
    }
  }

  render() {
    return (
      <div className="RawDataContainer PivotTable row">
        { (this.state.data)
          ? <PivotTableUI 
                onChange={s => this.setState(s)}
                renderers={Object.assign({}, TableRenderers, PlotlyRenderers)}
                      {...this.state}
              />
          : <div><img src={ loading } alt="Loading Icon" /></div>
        }
      </div>
    )
  }
}

export default RawData;
