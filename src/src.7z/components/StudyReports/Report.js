import React, {Component} from 'react';
import RawData from './RawData';

import { Row, Col } from 'reactstrap';

import 'react-widgets/dist/css/react-widgets.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 

import 'jquery/dist/jquery.min.js';
import 'popper.js/dist/popper.min.js';
import 'bootstrap/dist/js/bootstrap.min.js';


class Report extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ReportType:"RawData",
      ssid:null,
      batchnum:null,
    }

    this.handleChange = this.handleChange.bind(this)
  }

  handleChange = (e) => {
    const {name, value} = e.target;
    this.setState(prevState => ({ [name]: [value] }))
  }

  submit = (e) => {
    e.preventDefault()

    this.setState({'ssid':document.getElementById('ssid').value})
    this.setState({'batchnum':document.getElementById('batchnum').value})
  }

  render() {
    return (
      <div className="col-md-12">
        <div className="row">
          <div className="col-md-12">
            <form id="form" onSubmit={this.submit}>
              <input id="ssid" name="ssid" placeholder="ssid" />
              <input id="batchnum" name="batchnum" placeholder="batchnum" />
              <input type="submit" value="submit" />
            </form>

            {/* <button onClick={ this.toggleDatamap.bind(this) }>Show Datamap</button> */}
          </div>
          {/* <div className="col-md-3">
            { (this.state.ssid && this.state.batchnum)
              ? <DataMap 
                  state={this.state} 
                  handleChange={this.handleChange}
                />
              : <div className="col-md-12" style={{fontSize:".75rem"}}>datamap will be loaded when you enter ssid/batchnum</div>
            }
          </div> */}

          <div className="col-md-6">
            { (this.state.ssid && this.state.batchnum) 
                ? <RawData 
                    handleChange={this.handleChange}
                    state={this.state}
                  />
                : <div className="col-md-12">Enter ssid and batchnum to pull data.</div>
            }
          </div>
        </div>
      </div>
    )
  }
}

export default Report;