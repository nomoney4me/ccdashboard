import React, { Component } from 'react'

class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      eMailAddress: "tien@ccmar.com",
      
    }
  }

  componentWillMount() {
    if(this.props.data) {
      this.setState({
        FirstName: this.props.data.FirstName,
        LastName: this.props.data.LastName,
        Birthdate: this.props.data.Birthdate,
        Gender: this.props.data.Gender,
        Tel: this.props.data.Tel,
        Address: this.props.data.Address,
        City: this.props.data.City,
        State: this.props.data.State,
        PostalCode: this.props.data.PostalCode,
      })
    }
  }
  
  confirm = () => {
     if(this.state.eMailAddress && this.state.eMailAddress.match(/[@]/) && this.state.eMailAddress.match(/[.]/) ) {
      fetch(`${this.state.url}/getUserByEmail`, {
        headers: this.state.MyHeader,
        method:'post',
        body: JSON.stringify ({
          eMailAddress: this.state.eMailAddress
        })
      })
      .then(result => result.json())
      .then(data => data[0])
      .then(data => {
        if(data) { // has data
          data.Birthdate = moment.utc(data.Birthdate).format('YYYY-MM-DD');
          data.State = data.State.toUpperCase();

          this.setState({FoundUser: true})
          this.setState({
            
          })
        }
        else { // no email found
          // $("#reportBtn").hide()
          // $("#emailHelp-notfound").show()
          // $("#emailHelp-found").hide()
          // $("#eMailAddress").removeClass("successBox")
          // $("#mandatory > .form-control").prop("required", true)
        }
      })
    }else {
      alert('invalid email format, please try again')
      // $("#emailHelp").show()
      // $("#infoBlock").hide()
    }
  }
  validate_form = () => {
    let birthdate = $("#Birthdate").val()
    if(moment(birthdate).isAfter(moment().format('YYYY-MM-DD'))) {
      alert('invalid birthdate')
      return false
    }else {
      return true
    }
  }
  check_required = () => {
    let MissingFields = []
    $('input, select').filter('[required]:visible').each(function() {
      if( !$(this).val() ) MissingFields.push(JSON.stringify(this.id))
    })

    if(MissingFields.length > 0) {
      alert(`Invalid Fields: ${MissingFields}`)
      return false
    }else
      return true
  }
  addNew = () => {
    if( this.validate_form ) {
      fetch(`${this.state.url}/newuser`, {
        headers: this.MyHeader,
        method: 'post',
        body: JSON.stringify($("form").serializeArray())
      })
      .then(body => {
        if(body.status === 401) window.location = "./login.html"
        return body.json()})
      .then(data => {
        if(data.msg) alert('Account has been created: '+JSON.stringify(data.msg))
        else alert('Error: '+JSON.stringify(data))
      })
      .then(() => {
        this.clear_element(this.form)
        $("#eMailAddress").val('')
        $("#eMailAddress").keyup()
      })
    }
  }
  updateUser = () => {
    if(this.validate_form) {
      fetch(`${this.state.url}/updateUser/${this.CurrentPersonID}`, {
        headers: this.MyHeader,
        method: 'post',
        body: JSON.stringify($("form").serializeArray())
      })
      .then(body => {
        if(body.status === 401) window.location = "./login.html"
        return body.json()
      })
      .then(data => {
        $("#loading").show()
        alert('Account has been updated: '+JSON.stringify(data))
        $("#loading").hide()
      })
      .then(() => {
        this.clear_element(this.form)
        $("#eMailAddress").val('')
        $("#eMailAddress").removeClass("successBox")
        $("#emailHelp-found").hide()
        $("#infoBlock").hide()
      })
    }
  }
  submit = () => {
    if( this.check_required ) {
      if($("#emailHelp-notfound").is(':visible')) {
        console.log('account not found, adding new')
        this.addNew
      }else {
        console.log('account found, updating')
        this.updateUser
      }
    }
  }
  clear_element = (form) => {
    $(form).find(':input').each(function() {
      switch (this.type) {
        case 'password':
        case 'date':
        case 'select-multiple':
        case 'select-one':
        case 'text':
          if(this.id === 'SiteID') break;
        case 'textarea':
            $(this).val('');
            break;
        case 'checkbox':
        case 'radio':
            this.checked = false;
      }
    })
  }

  render() {
    return (
      <form id="form">
          <div className="form-group" id="Email">
            <label htmlFor="eMailAddress">Email:</label>
            <div className="form-inline align-middle">
              <input type="email" className="form-control mr-sm-2 col-8" name="eMailAddress" id="eMailAddress" value={this.state.eMailAddress} onChange={this.handleChange} required />
              <div id="confirmBtn" className="btn btn-primary mr-sm-1 col" onClick={this.confirm}><span id="confirmTxt">Find Panelist</span></div>
              <div id="reportBtn" className="btn btn-danger col" onClick={this.report}><span id="reportTxt">Report</span></div>
              <p><small id="emailHelp-notfound" className="form-text text-muted error">Email not found. Please fill out the following fields to add panelist.</small></p>
              <p><small id="emailHelp-found" className="form-text text-muted success">Email found! You can update the person's profile below.</small></p>
            </div>
          </div>
          <div id="loading">
            <img src="./assets/loading.gif" height={100} />
          </div>
          <div id="infoBlock">
            <div className="hr-sect" style={{color: 'red', fontWeight: 'bold'}}>MANDATORY FIELDS</div>
            <div id="mandatory">
              <div className="form-group">
                <label htmlFor="FirstName">Firstname:</label><input type="text" className="form-control" name="FirstName" id="FirstName" value={this.state.FirstName} required />
              </div>
              <div className="form-group">
                <label htmlFor="LastName">Lastname:</label><input type="text" className="form-control" name="LastName" id="LastName" value={this.state.LastName} required />
              </div>
              <div className="form-group">
              </div>
              <div className="form-group row mt-2">
                <div className="col-5"><label htmlFor="Birthdate">Birthdate</label>
                  <input type="date" className="form-control" name="Birthdate" id="Birthdate" max="9999-31-12" value={this.state.Birthdate} required />
                </div>
                <div className="col-3">
                  <label htmlFor="Gender" required>Gender: </label>
                  <select className="form-control" name="Gender" id="Gender" value={this.state.Gender} required>
                    <option value={1}>Male</option>
                    <option value={2}>Female</option>
                    <option value={0}>Other</option>
                  </select>
                </div>
                <div className="col-4">
                  <label htmlFor="Tel">Phone</label>
                  <input className="form-control" type="text" defaultValue id="Tel" name="Tel" min={0} max={10} value={this.state.Tel} required />
                </div>
              </div>
              <div className="form-group">
              </div>
            </div>
            <div className="hr-sect">OPTIONAL FIELDS</div>
            <div id="optional">
              <div className="form-group">
                <label htmlFor="Address">Address</label><input type="text" className="form-control" name="Address" id="Address" value={this.state.Address} />
                <div className="form-group row mt-2">
                  <div className="col-4"><label htmlFor="City">City</label><input type="text" className="form-control" name="City" id="City" value={this.state.City} /></div>
                  <div className="col-5"><label htmlFor="State">State</label>
                    <select className="form-control" name="State" id="State" value={this.state.State}>
                      <option value="AL">Alabama</option>
                      <option value="AK">Alaska</option>
                      <option value="AZ">Arizona</option>
                      <option value="AR">Arkansas</option>
                      <option value="CA">California</option>
                      <option value="CO">Colorado</option>
                      <option value="CT">Connecticut</option>
                      <option value="DE">Delaware</option>
                      <option value="DC">District Of Columbia</option>
                      <option value="FL">Florida</option>
                      <option value="GA">Georgia</option>
                      <option value="HI">Hawaii</option>
                      <option value="ID">Idaho</option>
                      <option value="IL">Illinois</option>
                      <option value="IN">Indiana</option>
                      <option value="IA">Iowa</option>
                      <option value="KS">Kansas</option>
                      <option value="KY">Kentucky</option>
                      <option value="LA">Louisiana</option>
                      <option value="ME">Maine</option>
                      <option value="MD">Maryland</option>
                      <option value="MA">Massachusetts</option>
                      <option value="MI">Michigan</option>
                      <option value="MN">Minnesota</option>
                      <option value="MS">Mississippi</option>
                      <option value="MO">Missouri</option>
                      <option value="MT">Montana</option>
                      <option value="NE">Nebraska</option>
                      <option value="NV">Nevada</option>
                      <option value="NH">New Hampshire</option>
                      <option value="NJ">New Jersey</option>
                      <option value="NM">New Mexico</option>
                      <option value="NY">New York</option>
                      <option value="NC">North Carolina</option>
                      <option value="ND">North Dakota</option>
                      <option value="OH">Ohio</option>
                      <option value="OK">Oklahoma</option>
                      <option value="OR">Oregon</option>
                      <option value="PA">Pennsylvania</option>
                      <option value="RI">Rhode Island</option>
                      <option value="SC">South Carolina</option>
                      <option value="SD">South Dakota</option>
                      <option value="TN">Tennessee</option>
                      <option value="TX">Texas</option>
                      <option value="UT">Utah</option>
                      <option value="VT">Vermont</option>
                      <option value="VA">Virginia</option>
                      <option value="WA">Washington</option>
                      <option value="WV">West Virginia</option>
                      <option value="WI">Wisconsin</option>
                      <option value="WY">Wyoming</option>
                    </select>
                  </div>
                  <div className="col-3"><label htmlFor="PostalCode">Zip</label><input type="text" className="form-control" name="PostalCode" id="PostalCode" value={this.state.PostalCode} /></div>
                </div>
              </div>
            </div>
            <div className="btn btn-primary" onClick={this.submit}>Submit </div>
          </div>
        </form>
    )
  }
}

export default Form;