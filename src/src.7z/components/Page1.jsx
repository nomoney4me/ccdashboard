import React from 'react'

export default () => {
  return (
    <div>
      <p>page 1 </p>
    </div>
  )
}
