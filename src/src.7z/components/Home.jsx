import React from 'react';
import { Table, Col, Row } from 'reactstrap';
import FontAwesome from 'react-fontawesome';

export default () => {
  return (
    <div>
      <p>Stickied Note: </p>
      <p>If you have any questions please click on the <FontAwesome name='question-circle' /> icons first.
        <br />If the <FontAwesome name='question-circle' /> does not answer your question, please send in a support ticket at <a href="http://support.ccmar.com">http://support.ccmar.com</a>.
      </p>
        <Table sm="6" md="6" lg="6">
          <tr>
            <td>
              5/23/2018
            </td>
            <td>
              Panelist Manager version 2.1 has been released!
              <ul>
                <li>Added Patch Notes page</li>
                <li>Added idle timeout</li>
                <li>Added <FontAwesome name='question-circle' /> icons for quick help</li>
                <li>Added reporting functions for project managers</li>
                <li>Added  <a href="https://localhost:8080/PanelistManager/static/media/PanelistManager_Instructions.d8d3ac2f.jpeg">flowchart</a></li>
                <li>Added email format validation</li>
                <li>Set Zipcode to be required</li>
              </ul>
            </td>
          </tr>
        </Table>

    </div>
  )
}
