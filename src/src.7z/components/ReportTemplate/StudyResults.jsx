import React, { Component } from 'react';

export default class StudyResults extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        study result here
      </div>
    );
  }
}
