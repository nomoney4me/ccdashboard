import React, { Component } from 'react'
import Cookies from 'js-cookie';

import ReactTable from "react-table";
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';

import { Col, Form, Input } from 'reactstrap';
import moment from 'moment';

class OfficeCounts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ReportData: [],
      fromDate: moment().format('YYYY-MM-DD'),
      toDate: moment().format('YYYY-MM-DD'),
    }
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value })
  }

  getCounts = (e) => {
    e.preventDefault();
    if(this.state.fromDate && this.state.toDate) {
      fetch(`${process.env.REACT_APP_URL}/report/counts`, {
        method:'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': Cookies.get('token')
        },
        body: JSON.stringify({
          fromDateCreated: this.state.fromDate,
          toDateCreated: this.state.toDate
        })
      }).then(resp => resp.json())
      .then(data => {
        console.log('data')
        this.setState({ ReportData: data})
      })
    }else {
      fetch(`${process.env.REACT_APP_URL}/report/counts`, {
        headers: {
          'x-access-token': Cookies.get('token')
        }
      }).then(resp => resp.json())
      .then(data => {
        console.log(data)
        this.setState({ ReportData: data})
      })
    }
  }

  render() {
    const data = this.state.ReportData;
    const columns = [
      {
        Header: "Description",
        accessor: "Description"
      },
      {
        Header: "Total",
        id: "Total",
        accessor: d => d.Total
      }
    ]
    return (
      <div>
        <Form inline onSubmit={this.getCounts} >
          From: <Input lg="5" type="date" name="fromDate" value={this.state.fromDate} onChange={this.handleChange} style={{marginRight:"25px"}} />
          To: <Input lg="5" type="date" name="toDate" value={this.state.toDate} onChange={this.handleChange} />
          <Input type="submit" />
        </Form>

        <hr />
        
        <Col sm="8" md="8" lg="8">
          <BootstrapTable data={ data } options={ { noDataText: 'No data, please choose a time frame to count.' } }>
            <TableHeaderColumn dataField='Description' isKey={ true } dataSort={true} >Offices</TableHeaderColumn>
            <TableHeaderColumn dataField='Total' dataSort={true} >Total Count</TableHeaderColumn>
          </BootstrapTable>
        </Col>
      </div>
    )
  }
}

export default OfficeCounts;

// ViewOfficeCounts = () => {
  // .then(function(data) {
  //   if(data.status === 401) window.location = "./login.html"
  //   return data.json() })
  // .then(function(data) {
  //   let TableHeaders = Object.keys(data[0]).map(function(item) {
  //     return `${item}`;
  //   }, [])

  //   let TableData = data.map(function(item) {
  //     return `<tr>
  //               <td>${item[TableHeaders[0]]}</td>
  //               <td>${item[TableHeaders[1]]}</td>
  //             </tr>`
  //   }, [])

  //   $("#TableHeaders").html("")
  //   TableHeaders.map(item => {
  //     $("#TableHeaders").append(`<th>${item}</th>`)
  //   })
  //   $("#TableData").html(TableData)
  // })
// }
