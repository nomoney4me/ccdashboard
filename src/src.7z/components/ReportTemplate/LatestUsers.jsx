import React, { Component } from 'react'
import Cookies from 'js-cookie';

import ReactTable from "react-table";

import moment from 'moment';

export default class LatestUsers extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ReportData: [],
      columns: [
        { Header: "FirstName", id: "FirstName", accessor: "FirstName" },
        { Header: "LastName", id: "LastName", accessor: "LastName" },
        { Header: "eMailAddress", id: "eMailAddress", accessor: "eMailAddress" },
        { Header: "Birthdate", id: "Birthdate", accessor: "Birthdate" },
        { Header: "Created By", id: "Created By", accessor: "Created By" },
        { Header: "DateCreated", id: "DateCreated", accessor: "DateCreated" },
      ],
    }
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value })
  }

  componentWillMount() {
    this.getLatestUsers()
  }

  getLatestUsers = () => {
    fetch(`${process.env.REACT_APP_URL}/report/latestusers`, {
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': Cookies.get('token')
      }
    })
    .then(resp => {
      if(resp.status !== 200) {
        throw 'server is down'
      }else {
        return resp.json() 
      }
    })
    .then(data => {
      this.setState({ReportData: data})
    })
    .catch(e => {
      console.log(e)
    })
  }

  render() {
    return (
      <div>
        { this.state.ReportData
          ? <ReactTable 
              data={this.state.ReportData} 
              columns={this.state.columns}
            />
          : ""
        }
      </div>
    )
  }
}