import React, { Component } from 'react';
import Cookies from 'js-cookie';
import moment from 'moment';

import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';

import ReactTable from 'react-table';
// import ReactPivot from 'react-pivot';

// import PivotTableUI from 'react-pivottable/PivotTableUI';
// import 'react-pivottable/pivottable.css';

import LoadingIMG from '../../../assets/images/loading.gif';

class StudiesList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      StudiesList: null,
      selectedStudy: {
        StudyDescription: "",
        StudyID: "",
      },
      selectedStudyResult: null,
    };

    this.toggle = this.toggle.bind(this);
    this.getStudyResult = this.getStudyResult.bind(this);
  }

  toggle = () => {
    this.setState({modal: !this.state.modal})
  }

  getStudyList = () => {
    fetch(`${process.env.REACT_APP_URL}/report/studies`, {
      method:'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': Cookies.get('token')
      }
    }).then(resp => resp.json())
    .then(data => {
      this.setState({ StudiesList: data})
    })
  }

  getStudyResult = (StudyID) => {
    this.setState({selectedStudyResult: null})

    fetch(`${process.env.REACT_APP_URL}/report/studyresults?StudyID=${StudyID}`, {
      headers: {
        'x-access-token': Cookies.get('token')
      },
      method:'post'
    }).then(res => res.json())
    .then(data => {
      // console.log(data)
      this.setState({selectedStudyResult: data})
    })
    
  }


  componentDidMount() {
    this.getStudyList()
  }

  render() {
    const data = this.state.StudiesList;
    const onRowClick = (state, rowInfo, column, instance) => {
      // return {
      //   onClick: e => {
      //     let row = rowInfo.row['_original'];
      //     this.setState({ selectedStudy: row });
      //     this.getStudyResult(row.studyid);

      //     this.toggle();
      //   },
      // };
    };

    const options = {
      noDataText: 'No data, please choose a time frame to count.',
      btnGroup: this.createCustomButtonGroup = (props) => {
        return (
          <ButtonGroup style={{marginTop:"20px"}} className='my-custom-class' sizeClass='btn-group-md'>
            { props.showSelectedOnlyBtn }
            { props.exportCSVBtn }
            { props.insertBtn }
            { props.deleteBtn }
          </ButtonGroup>
        );
      }
    }

    function dateFormat(value) {
      return moment.utc(value).format('MM/DD/YYYY HH:mm:ss')
    }


    return (
      <div>
        {/* <Modal size="lg" isOpen={this.state.modal} toggle={this.toggle} className="class name goes here">
          <ModalHeader toggle={this.toggle}>
            { this.state.selectedStudy.StudyDescription }
          </ModalHeader>
          <ModalBody>
            { this.state.selectedStudyResult
                ? <ReactPivot rows={this.state.selectedStudyResult} />
                : <img src={LoadingIMG} height="150px" alt="" /> }
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.toggle}>Close</Button>
          </ModalFooter>
        </Modal> */}

        { /* ---- BootstrapTable ----*/ }
        <BootstrapTable data={ data } options={ options } exportCSV>
          <TableHeaderColumn dataField='studyid' width="100px" isKey={ true } dataSort={true} >Study ID</TableHeaderColumn>
          <TableHeaderColumn dataField='suspended' width="100px" dataSort={true} >Suspended</TableHeaderColumn>
          <TableHeaderColumn dataField='starttime' width="175px" dataSort={true} dataFormat={ dateFormat } >Start Time</TableHeaderColumn>
          <TableHeaderColumn dataField='ExpirationDate' width="175px" dataSort={true} dataFormat={ dateFormat } >End Time</TableHeaderColumn>
          <TableHeaderColumn dataField='panelsize' width="100px" dataSort={true} >Panel Size</TableHeaderColumn>
          {/* <TableHeaderColumn dataField='url' dataSort={true} >Link</TableHeaderColumn> */}
        </BootstrapTable>

        { /* --- React Table --- */ }

        
      </div>
    );
  }
}

export default StudiesList;

