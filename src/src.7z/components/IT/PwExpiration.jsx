import React, { Component } from 'react';
import { HorizontalBar } from 'react-chartjs-2';
import {
  Button,
  ButtonGroup,
  ButtonToolbar,
  Card,
  CardBody,
  CardTitle,
  Col,
  Row,
} from 'reactstrap';

import moment from 'moment';
import Cookies from 'js-cookie';

const mainChartOpts = {
  tooltips: {
    enabled: true,
    custom: (tooltipModel) => {

    }
  },
  maintainAspectRatio: false,
  scales: {
    yAxes: [
      {
        gridLines: {
          drawOnChartArea: false,
        },
      }],
    xAxes: [
      {
        ticks: {
          beginAtZero: true,
          stepSize: Math.ceil(90 / 9),
          max: 90,
        },
      }],
  },
  // elements: {
  //   point: {
  //     radius: 0,
  //     hitRadius: 10,
  //     hoverRadius: 4,
  //     hoverBorderWidth: 3,
  //   },
  // },
};


class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);
    this.getCounts = this.getCounts.bind(this);

    this.state = {
      dropdownOpen: false,
      radioSelected: 2,
      mainChartData: null,
    };
  }

  componentWillMount() {
    this.getCounts()
  }

  getCounts() {
    fetch(`${process.env.REACT_APP_URL}/listpwexpiration`, {
      method: "get",
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': Cookies.get('token')
      },
    })
    .then(data => {
      return data.json()
    })
    .then(data => { // sort and filter data by expiration date
      let sortedData = Object.keys(data).filter(key => {
        if(data[key].pwdLastSet >= 80){
          return true;
        }
      }).map(k => data[k], [])
      return sortedData;
    })
    .then(data => {
      let chartData = {
        labels: [],
        datasets: [{
            label: 'Over 90 days',
            data: [],
            backgroundColor: [],
            borderColor: [],
            borderWidth: 1
        }]
      }

      Object.keys(data).reduce((r, k) => {
        let xaxis = "sAMAccountName";
        let yaxis = "pwdLastSet";
        
        if( data[k][xaxis] ) {
          chartData.labels.push( data[k][xaxis] )
          if( data[k][yaxis] > 90) {
            chartData.datasets[0].data.push( data[k][yaxis] )
            chartData.datasets[0].backgroundColor.push( "#ffd8d8" )
            chartData.datasets[0].borderColor.push( "#ff9393" )
          }else {
            chartData.datasets[0].data.push( data[k][yaxis] )
            chartData.datasets[0].backgroundColor.push( "#cccccc" )
            chartData.datasets[0].borderColor.push( "#ffffff" )
          }

        }

        // if( data[k][xaxis] ) {
        //   tmpLabels.push(data[key][xaxis])
        //   tmpDataset.push(data[key][yaxis])
        //   if( data[key][yaxis] >= 90) {
        //     backgroundColor.push('#ffd8d8')
        //     borderColors.push('#ff8e8e')
        //   }else {
        //     backgroundColor.push('#cccccc')
        //     borderColors.push('#dddddd')
        //   }
        // }else {
        //   tmpDataset.push(0)
        //   backgroundColor.push('#cccccc')
        //   borderColors.push('#ffffff')
        // }
      })
      console.log(chartData)

      this.setState({ mainChartData: chartData })
    })
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }

  onRadioBtnClick(radioSelected) {
    this.getCounts(radioSelected)

    this.setState({
      radioSelected: radioSelected,
    });
  }

  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardBody>
                <Row>
                  <Col sm="5">
                    <CardTitle className="mb-0">Password Expiration</CardTitle>
                    <div className="small text-muted">{ moment().format('MMMM Do YYYY, h:mm:ss a') }</div>
                  </Col>
                  <Col sm="7" className="d-none d-sm-inline-block">
                    {/* <Button color="primary" className="float-right"><i className="icon-cloud-download"></i></Button> */}
                    <ButtonToolbar className="float-right" aria-label="Toolbar with button groups">
                      <ButtonGroup className="mr-3" aria-label="First group">
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(1)} active={this.state.radioSelected === 1}>Day</Button>
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(2)} active={this.state.radioSelected === 2}>Month</Button>
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(3)} active={this.state.radioSelected === 3}>Year</Button>
                      </ButtonGroup>
                    </ButtonToolbar>
                  </Col>
                </Row>
                <div className="chart-wrapper" style={{ height: 800 + 'px', marginTop: 40 + 'px' }}>
                  { this.state.mainChartData 
                    ? <HorizontalBar data={this.state.mainChartData} options={mainChartOpts} height={800} />
                    : ""
                  }
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Dashboard;
