import React, { Component } from 'react';
import { HorizontalBar } from 'react-chartjs-2';
import {
  Button,
  ButtonGroup,
  ButtonToolbar,
  Card,
  CardBody,
  CardTitle,
  Col,
  Row,
} from 'reactstrap';

import moment from 'moment';
import Cookies from 'js-cookie';

const mainChartOpts = {
  tooltips: {
    
  },
  maintainAspectRatio: false,
  legend: {
    display: false,
  },
  scales: {
    xAxes: [
      {
        gridLines: {
          drawOnChartArea: false,
        },
      }],
    yAxes: [
      {
        ticks: {
          beginAtZero: true,
          maxTicksLimit: 5,
          stepSize: Math.ceil(250 / 5),
          max: 250,
        },
      }],
  },
  elements: {
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    },
  },
};


class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);
    this.getCounts = this.getCounts.bind(this);

    this.state = {
      dropdownOpen: false,
      radioSelected: 2,
      mainChartData: null,
    };
  }

  componentWillMount() {
    this.getCounts(this.state.radioSelected)
  }

  getCounts(daterange) {
    console.log(daterange)
    let bodydata;
    switch (daterange) {
      case 1:
        bodydata = {
          fromDateCreated: moment.utc().format('YYYY-MM-DD'),
          toDateCreated: moment.utc().format('YYYY-MM-DD')
        }
        break;
      case 2:
        bodydata = {
          fromDateCreated: moment.utc().startOf('month').format('YYYY-MM-DD'),
          toDateCreated: moment.utc().format('YYYY-MM-DD')
        }
        break;
      case 3:
        bodydata = {
          fromDateCreated: moment.utc().startOf('year').format('YYYY-MM-DD'),
          toDateCreated: moment.utc().format('YYYY-MM-DD')
        }
        break;
      default:
        break;
    }


    fetch(`https://sync.gui.cc/arcsapi2/report/counts`, {
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': Cookies.get('token')
      },
      method: 'post',
      body: JSON.stringify(bodydata)
    })
    .then(data => {
      return data.json()
    })
    .then(data => {
      let tmpLabels = []; 
      let tmpDataset = [];
      let tmpLabelsColor = [];   

      Object.keys(data).map(key => {
        if(data[key].Description) {
          tmpLabels.push(data[key].Description)
          tmpLabelsColor.push("#000000".replace(/0/g,function(){return (~~(Math.random()*16)).toString(16)}))
        }
        if(data[key].Total) {
          tmpDataset.push(data[key].Total)
        }else {
          tmpDataset.push(0)
        }
      })

      let tmpData = {
        labels: tmpLabels,
        datasets: [{
          label: "Panelist Added (total)",
          backgroundColor: tmpLabelsColor,
          data: tmpDataset
        }]
      }
      
      this.setState({ mainChartData: tmpData })
    })
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }

  onRadioBtnClick(radioSelected) {
    this.getCounts(radioSelected)

    this.setState({
      radioSelected: radioSelected,
    });
  }

  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardBody>
                <Row>
                  <Col sm="5">
                    <CardTitle className="mb-0">Panelist Count Summary</CardTitle>
                    <div className="small text-muted">{ moment().format('MMMM Do YYYY, h:mm:ss a') }</div>
                  </Col>
                  <Col sm="7" className="d-none d-sm-inline-block">
                    {/* <Button color="primary" className="float-right"><i className="icon-cloud-download"></i></Button> */}
                    <ButtonToolbar className="float-right" aria-label="Toolbar with button groups">
                      <ButtonGroup className="mr-3" aria-label="First group">
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(1)} active={this.state.radioSelected === 1}>Day</Button>
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(2)} active={this.state.radioSelected === 2}>Month</Button>
                        <Button color="outline-secondary" onClick={() => this.onRadioBtnClick(3)} active={this.state.radioSelected === 3}>Year</Button>
                      </ButtonGroup>
                    </ButtonToolbar>
                  </Col>
                </Row>
                <div className="chart-wrapper" style={{ height: 800 + 'px', marginTop: 40 + 'px' }}>
                  { this.state.mainChartData 
                    ? <HorizontalBar data={this.state.mainChartData} options={mainChartOpts} height={800} redraw />
                    : ""
                  }
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Dashboard;
