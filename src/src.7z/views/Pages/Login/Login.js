import React, { Component } from 'react';
import { Form, Button, Card, CardBody, CardGroup, Col, Container, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';

import Cookies from 'js-cookie';
import PopoverItem from '../../../components/PopoverItem';

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
    }

    this.handleChange = this.handleChange.bind(this)
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value})
  }

  submit = (e) => {
    e.preventDefault()
    fetch(`${process.env.REACT_APP_URL}/authenticate`, {
      headers: {
        'Content-Type': 'application/json'
      },
      method: 'post',
      body: JSON.stringify({
        username: this.state.username,
        password: this.state.password
      })
    })
    .then(resp => {
      switch (resp.status) {
        case 401:
          window.alert(resp.statusText)
          break;

        case 500:
          window.alert(resp.statusText)
          break;

        default:
          return resp
      }
    })
    .then(data => data.json()).then(data => {
      if(data.token) {
        Cookies.set('token', data.token)
        window.location = "./"
      }
    })
  }

  render() {
    return (
      <div className="app flex-row align-items-center">
        
          <Container>
            <Row className="justify-content-center">
              <Col md="8">
                <Form onSubmit={this.submit} >
                  <CardGroup>
                    <Card className="p-4">
                      <CardBody>
                        <h1>Login</h1>
                        <p className="text-muted">Sign In to your account</p>
                        <InputGroup className="mb-3">
                          <InputGroupAddon addonType="prepend">
                            <InputGroupText>
                              <i className="icon-user"></i>
                            </InputGroupText>
                          </InputGroupAddon>
                          <Input type="text" placeholder="Username" value={this.state.username} onChange={this.handleChange} name="username" />
                        </InputGroup>
                        <InputGroup className="mb-4">
                          <InputGroupAddon addonType="prepend">
                            <InputGroupText>
                              <i className="icon-lock"></i>
                            </InputGroupText>
                          </InputGroupAddon>
                          <Input type="password" placeholder="Password" value={this.state.password} onChange={this.handleChange} name="password" />
                        </InputGroup>
                        <Row>
                          <Col xs="6">
                            <Button color="primary" className="px-4">Login</Button>
                          </Col>
                          <Col xs="6" className="text-right">
                            Forgot Password <PopoverItem style={{marginLeft:"10px"}} id="popover-finding-report" title="Login Instruction" body="* Username: Your AD Username \n * Password: Your AD Password \n Note: If you have issues, please submit a ticket with the username that you are trying to login with." />
                          </Col>
                        </Row>
                      </CardBody>
                    </Card>
                  </CardGroup>
                </Form>
              </Col>
            </Row>
          </Container>
      </div>
    );
  }
}

export default Login;
